<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Admin;
use Illuminate\Support\Facades\Hash;

class MainController extends Controller
{
    public function login(){
        return view('Auth.login');
    }

    public function register(){
        return view('Auth.register');
    }

    public function save(Request $request){
        $request->validate
            (
                [
                "name"=>'required',
                "email"=>'required|email|unique:admins',
                "password"=>'required|min:5|max:8'

                ]
            );

            $admin=new Admin;
            $admin->name=$request->name;
            $admin->email=$request->email;
            $admin->password=Hash::make($request->password);
            $save=$admin->save();
            if($save)
            return back()->with('success','New user has been added');

            else{
                return back()->with('fail','Something went wrong');
            }

    }

    public function check(Request $request){

        $request->validate
            (
            [
                'email'=>'required|email',
                'password'=>'required|min:5|max:8'
            ]
            );

            $userInfo=Admin::where('email','=',$request->email)->first();
            if(!$userInfo){
                return back()->with('fail','we do not recognize your email ');
            }else{
                if(Hash::check($request->password,$userInfo->password)){
                    $request->session()->put('LoggedUser',$userInfo->id);
                    return redirect('admin/dashboard');
                }else{
                    return back()->with('fail','Incorrect password');
                }
            }
    }

    public function logout(){
        if(Session()->has('LoggedUser')){
            Session()->pull('LoggedUser');
            return redirect('auth/login');
        }
    }

    public function dashboard(){
        $data=['LoggedUserInfo'=>Admin::where('id','=',session('LoggedUser'))->first()];
        return view('admin.dashboard',$data);
    }
}
